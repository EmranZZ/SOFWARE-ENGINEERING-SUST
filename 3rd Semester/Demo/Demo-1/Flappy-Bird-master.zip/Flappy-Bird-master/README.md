Flappy-Bird
===========

A flappy bird clone written in Java, for the ICS4U Simple Game Assignment.

<img src="https://raw.githubusercontent.com/paulkr/Flappy-Bird/master/demo.png" width="500" />

Build & Run
-----------

```shell
$ cd lib
$ javac FlappyBird.java && java FlappyBird
```
