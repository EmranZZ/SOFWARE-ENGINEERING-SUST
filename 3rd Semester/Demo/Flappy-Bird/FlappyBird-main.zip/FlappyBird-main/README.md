# FlappyBird
A FlappyBird clone in swing

This is a simple clone of flappy bird made in Java Swing. Part of the game is made using a custom engine. Hope you enjoy this game, it is challenging.

If you wish to download this game, the site is https://sourceforge.net/projects/swing-flappy-bird/
